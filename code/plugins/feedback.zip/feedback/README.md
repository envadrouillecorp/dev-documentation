plugin-feedback
===============

Plugin that adds a "feedback button" to an existing EnVadrouille gallery.

To install:
* Create the following directory: ./admin/pages/feedback
* Put all files of this repository in that directory
* Go in the options and activate the plugin. Don't forget to put your email.
