known_sentences.concat({
   'Feedback Plugin':'Feedback Plugin',
   'feedback_activated':'Activate plugin',
   'feedback_mail':'Email that will receive feedback messages',
});
