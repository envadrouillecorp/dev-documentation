known_sentences.concat({
   'gps' : 'GPS:',
	'up_gpx' : 'Choose GPX',
	'rm_gpx' : 'Remove',
   'uploading_gpx':'Uploading GPX file...',
	't_added_gpx':'(If you have put a GPX file in this directory, it will be automatically added.)',
});

