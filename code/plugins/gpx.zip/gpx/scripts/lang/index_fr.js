known_sentences.concat({
   'gps' : 'GPS :',
	'up_gpx' : 'Parcourir',
	'rm_gpx' : 'Supprimer',
   'uploading_gpx':'Envoi du fichier GPX...',
	't_added_gpx':'(Si vous avez plac� un fichier gpx dans ce dossier, il sera ajout� automatiquement.)',
});
