known_sentences.concat({
   'gps' : 'GPS :',
	'up_gpx' : 'Parcourir',
	'rm_gpx' : 'Supprimer',
   'uploading_gpx':'Envoi du fichier GPX...',
	't_added_gpx':'(Si vous avez plac� un fichier gpx dans ce dossier, il sera ajout� automatiquement.)',
   'gps_time_diff':'Difference&nbsp;entre&nbsp;l\'heure&nbsp;de&nbsp;l\'appareil&nbsp;et&nbsp;le&nbsp;GPS&nbsp;:',
   'geo_all_pics':'Utiliser&nbsp;l\'heure&nbsp;dans&nbsp;la&nbsp;g�olocalisation?',
});
