known_sentences.concat({
   'GPX':'GPX<br/><p style="font-size:12px;font-style:normal">To show gpx files on IGN maps, you have to register for a developer key <a href="http://professionnels.ign.fr/api-web">here</a> (when registering for a key, check everything when the site asks you which functions of the API you want to access). Note: IGN maps only work for tracks recorded in France.</p>',
   'gpx_activated':'Activate gpx support',
   'gpx_type':'Default Map Style',
   'ign_key':'IGN API key (optional)',
   'gpx':'Map',
});

