known_sentences.concat({
   'GPX':'GPX<br/><p style="font-size:12px;font-style:normal">Pour afficher les cartes IGN, vous devez obtenir une clef de d�velopement <a href="http://professionnels.ign.fr/api-web">ici</a> (cochez toutes les fonctions de l\'API lorsque le site le demande). Note: les cartes IGN ne couvrent que le territoire fran�ais.</p>',
   'gpx_activated':'Activer le support des gpx',
   'gpx_type':'Carte par d�faut',
   'ign_key':'Clef pour l\'API IGN (optionnel)',
   'gpx':'Carte',
});

