known_sentences.concat({
   'GPX':'GPX<br/><p style="font-size:12px;font-style:normal">Pour afficher les cartes IGN, vous devez obtenir une clef de d�velopement <a href="http://professionnels.ign.fr/api-web">ici</a> (cochez toutes les fonctions de l\'API lorsque le site le demande). Note: les cartes IGN ne couvrent que le territoire fran�ais.<br/>Pour r�gler le d�callage en heure entre l\'appareil photo et le GPS, une petite astuce: affichez une galerie avec des photos et une trace GPS puis affichez les statistiques du parcours. En survolant le titre "Statistiques" du graphique, une popup contenant les dates de d�but et de fin du parcours + la date de la premi�re photo apparaitra. Note: il est possible de configurer ce d�callage par galerie sur la page des galeries.</p>',
   'gpx_activated':'Activer le support des gpx',
   'gpx_type':'Carte par d�faut',
   'ign_key':'Clef pour l\'API IGN (optionnel)',
   'allow_refugesinfo':'Autoriser l\'affichage des fonds de refuges.info',
   'gpx':'Carte',
   'geolocalization':'Afficher les photos sur la carte',
   'show_map_coord':'Afficher les images geotagg�es m�me en l\'absence de gpx',
   'geo_use_time':'Utiliser l\'heure de la prise de vue et le gpx pour trouver les coordon�es',
   'default_geo_time_diff':'Diff�rence (en heures) entre l\'appareil photo et le GPS',
});

