known_sentences.concat({
   'Facial Recognition':'Reconnaissance faciale<br/><p style="font-size:12px;font-style:normal">La galerie peut d�tecter des visages dans vos images. La galerie commence par rechercher des donn�es XMP dans vos images, vous pouvez donc tagger vos images avec des logiciels qui g�rent le XMP; ces tags seront automatiquement import�s. Picasa, par exemple, g�re le XMP (allez <a href="https://sites.google.com/site/picasaresources/Home/Picasa-FAQ/picasa/general-information/where-does-picasa-store-facetags">ici</a> pour voir comment le configurer). Vous pouvez aussi vous enregistrer sur l\'un des sites list�s plus bas (par exemple allez sur rekognition.com et demandez une clef). Si vous cochez l\'option de tag automatique, la galerie vous suggera des noms sur les visages reconnus (beta).</p>',
   'face_activated':'Activer la reconnaissance faciale',
   'do_recognition':'Tagger les visages automatiquement',
   'show_face':'Activer l\'onglet de reconnaissance faciale',
   'face_pub':'API, cl� publique',
   'face_key':'API, cl� priv�e (si elle existe)',
   'face_namespace':'API, namespace (ex: le nom de votre galerie sans espace)',
   'face_plugin':'API',
   'face_use_xmp':'Utiliser les tags XMP',
});
